import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:just_audio/just_audio.dart';
import 'package:video_player/video_player.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest_all.dart' as tz;
import 'package:timezone/timezone.dart' as tz;
import 'package:adhan/adhan.dart';
import 'package:hijri/hijri_calendar.dart';
import 'package:dio/dio.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
    FlutterLocalNotificationsPlugin();

final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  try {
    await Firebase.initializeApp();
  } catch (_) {}
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
  ));

  try {
    await Firebase.initializeApp();
    FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
  } catch (_) {}

  try {
    tz.initializeTimeZones();
    await AdhanAlarmService.init();
  } catch (_) {}

  // الدخول الفوري للتطبيق بدون شاشة انترو
  runApp(const QuranakApp());
}

// ============================================================================
// 1. ALARM-STYLE ADHAN NOTIFICATION SERVICE (منبه الأذان الإسلامي + 7 أيام أوفلاين)
// ============================================================================
class AdhanAlarmService {
  static const String adhanAlarmChannelId = 'quranak_adhan_alarm_v5';
  static const String adminChannelId = 'quranak_admin_broadcast_v5';

  static Future<void> init() async {
    const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    const iosInit = DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
    );

    await flutterLocalNotificationsPlugin.initialize(
      const InitializationSettings(android: androidInit, iOS: iosInit),
      onDidReceiveNotificationResponse: (NotificationResponse details) {
        if ((details.payload ?? '').startsWith('adhan:')) {
          final prayerName = details.payload!.replaceFirst('adhan:', '');
          navigatorKey.currentState?.push(
            MaterialPageRoute(
              builder: (_) => AdhanAlarmScreen(prayerName: prayerName),
            ),
          );
        }
      },
    );

    final androidExt = flutterLocalNotificationsPlugin
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();

    await androidExt?.requestNotificationsPermission();
    await androidExt?.requestExactAlarmsPermission();

    // قناة منبه الأذان: صوت أذان كامل + تنبيه ملء الشاشة + اهتزاز + تخطي وضع الصامت
    await androidExt?.createNotificationChannel(
      const AndroidNotificationChannel(
        adhanAlarmChannelId,
        'منبه الأذان ومواقيت الصلاة',
        description: 'تنبيه الأذان الكامل كالمنبه عند دخول وقت الصلاة',
        importance: Importance.max,
        playSound: true,
        sound: RawResourceAndroidNotificationSound('adhan'),
        enableVibration: true,
        enableLights: true,
        audioAttributesUsage: AudioAttributesUsage.alarm,
      ),
    );

    await androidExt?.createNotificationChannel(
      const AndroidNotificationChannel(
        adminChannelId,
        'إشعارات تطبيق قرآنك',
        description: 'إشعارات وتنبيهات الإدارة',
        importance: Importance.high,
      ),
    );

    try {
      await FirebaseMessaging.instance.requestPermission();
      await FirebaseMessaging.instance.subscribeToTopic('quranak_all_users');
      FirebaseMessaging.onMessage.listen((RemoteMessage msg) {
        final n = msg.notification;
        if (n != null) {
          showAdminBroadcast(n.title ?? 'قرآنك', n.body ?? '');
        }
      });
    } catch (_) {}
  }

  static Future<void> showAdminBroadcast(String title, String body) async {
    try {
      await flutterLocalNotificationsPlugin.show(
        DateTime.now().millisecondsSinceEpoch ~/ 1000,
        title,
        body,
        const NotificationDetails(
          android: AndroidNotificationDetails(
            adminChannelId,
            'إشعارات تطبيق قرآنك',
            importance: Importance.high,
            priority: Priority.high,
          ),
          iOS: DarwinInitializationDetails(),
        ),
      );
    } catch (_) {}
  }

  static Future<void> triggerTestAdhanAlarm(String prayerName) async {
    try {
      await flutterLocalNotificationsPlugin.show(
        9991,
        '🕌 حان الآن موعد $prayerName',
        'الله أكبر الله أكبر • حيّ على الصلاة • اضغط لإيقاف الأذان',
        NotificationDetails(
          android: AndroidNotificationDetails(
            adhanAlarmChannelId,
            'منبه الأذان ومواقيت الصلاة',
            importance: Importance.max,
            priority: Priority.max,
            category: AndroidNotificationCategory.alarm,
            fullScreenIntent: true,
            ongoing: true,
            autoCancel: false,
            playSound: true,
            sound: const RawResourceAndroidNotificationSound('adhan'),
            audioAttributesUsage: AudioAttributesUsage.alarm,
            additionalFlags: Int32List.fromList(<int>[4]), // FLAG_INSISTENT (يكرر صوت الأذان كالمنبه)
            actions: const <AndroidNotificationAction>[
              AndroidNotificationAction(
                'stop_adhan',
                'إيقاف الأذان',
                showsUserInterface: true,
                cancelNotification: true,
              ),
            ],
          ),
          iOS: const DarwinInitializationDetails(
            presentAlert: true,
            presentSound: true,
            sound: 'adhan.mp3',
            interruptionLevel: InterruptionLevel.timeSensitive,
          ),
        ),
        payload: 'adhan:$prayerName',
      );
    } catch (_) {}
  }

  static Future<Map<String, DateTime>> schedule7DaysForCity(double lat, double lng, String cityAr) async {
    final coords = Coordinates(lat, lng);
    final params = CalculationMethod.egyptian.getParameters();
    params.madhab = Madhab.shafi;

    try {
      await flutterLocalNotificationsPlugin.cancelAll();
      final now = DateTime.now();
      int notifId = 7000;

      for (int day = 0; day < 7; day++) {
        final dt = now.add(Duration(days: day));
        final pt = PrayerTimes(coords, DateComponents.from(dt), params);
        final prayers = [
          MapEntry('صلاة الفجر', pt.fajr),
          MapEntry('صلاة الظهر', pt.dhuhr),
          MapEntry('صلاة العصر', pt.asr),
          MapEntry('صلاة المغرب', pt.maghrib),
          MapEntry('صلاة العشاء', pt.isha),
        ];

        for (final p in prayers) {
          if (p.value.isAfter(now)) {
            final scheduled = tz.TZDateTime.from(p.value, tz.local);
            await flutterLocalNotificationsPlugin.zonedSchedule(
              notifId++,
              '🕌 حان الآن موعد ${p.key} ($cityAr)',
              'الله أكبر الله أكبر • حيّ على الصلاة • حيّ على الفلاح',
              scheduled,
              NotificationDetails(
                android: AndroidNotificationDetails(
                  adhanAlarmChannelId,
                  'منبه الأذان ومواقيت الصلاة',
                  importance: Importance.max,
                  priority: Priority.max,
                  category: AndroidNotificationCategory.alarm,
                  fullScreenIntent: true,
                  ongoing: true,
                  autoCancel: false,
                  playSound: true,
                  sound: const RawResourceAndroidNotificationSound('adhan'),
                  audioAttributesUsage: AudioAttributesUsage.alarm,
                  additionalFlags: Int32List.fromList(<int>[4]), // FLAG_INSISTENT كالمنبه تماماً
                  actions: const <AndroidNotificationAction>[
                    AndroidNotificationAction(
                      'stop_adhan',
                      'إيقاف الأذان',
                      showsUserInterface: true,
                      cancelNotification: true,
                    ),
                  ],
                ),
                iOS: const DarwinInitializationDetails(
                  presentAlert: true,
                  presentSound: true,
                  sound: 'adhan.mp3',
                  interruptionLevel: InterruptionLevel.timeSensitive,
                ),
              ),
              payload: 'adhan:${p.key}',
              androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
              uiLocalNotificationDateInterpretation:
                  UILocalNotificationDateInterpretation.absoluteTime,
            );
          }
        }
      }
    } catch (_) {}

    final today = PrayerTimes.today(coords, params);
    return {
      'Fajr': today.fajr,
      'Sunrise': today.sunrise,
      'Dhuhr': today.dhuhr,
      'Asr': today.asr,
      'Maghrib': today.maghrib,
      'Isha': today.isha,
    };
  }
}

// ============================================================================
// 2. FULL-SCREEN ADHAN ALARM SCREEN (شاشة منبه الأذان عند دخول وقت الصلاة)
// ============================================================================
class AdhanAlarmScreen extends StatefulWidget {
  final String prayerName;
  const AdhanAlarmScreen({super.key, required this.prayerName});

  @override
  State<AdhanAlarmScreen> createState() => _AdhanAlarmScreenState();
}

class _AdhanAlarmScreenState extends State<AdhanAlarmScreen> {
  final AudioPlayer _player = AudioPlayer();

  @override
  void initState() {
    super.initState();
    _playAdhan();
  }

  Future<void> _playAdhan() async {
    try {
      await _player.setAsset('assets/audio/adhan.mp3');
      await _player.play();
    } catch (_) {
      try {
        await _player.setUrl('https://www.islamcan.com/audio/adhan/azan1.mp3');
        await _player.play();
      } catch (_) {}
    }
  }

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF0A2A25), Color(0xFF0D2B35), Color(0xFF07131C)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.mosque_rounded, size: 84, color: Color(0xFFC9A959)),
              const SizedBox(height: 20),
              const Text('حان الآن موعد', style: TextStyle(fontSize: 20, color: Colors.white70)),
              const SizedBox(height: 8),
              Text(
                widget.prayerName,
                style: const TextStyle(fontSize: 38, fontWeight: FontWeight.w900, color: Color(0xFFC9A959)),
              ),
              const SizedBox(height: 16),
              const Text(
                'اللَّهُ أَكْبَرُ اللَّهُ أَكْبَرُ • حَيَّ عَلَى الصَّلَاةِ',
                style: TextStyle(fontSize: 18, color: Color(0xFFE2C78A)),
              ),
              const SizedBox(height: 50),
              ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFC9A959),
                  foregroundColor: Colors.black,
                  padding: const EdgeInsets.symmetric(horizontal: 36, vertical: 16),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(40)),
                ),
                onPressed: () async {
                  await _player.stop();
                  await flutterLocalNotificationsPlugin.cancelAll();
                  if (mounted) Navigator.pop(context);
                },
                icon: const Icon(Icons.alarm_off_rounded, size: 26),
                label: const Text('إيقاف الأذان', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ============================================================================
// 3. UNIVERSAL RECITER & MEDIA IMAGE RESOLVER (حل نهائي لمشكلة عدم ظهور صورة القارئ)
// ============================================================================
class ReciterAvatarImage extends StatelessWidget {
  final Map<String, dynamic> data;
  final double size;
  final double borderWidth;

  const ReciterAvatarImage({
    super.key,
    required this.data,
    this.size = 76,
    this.borderWidth = 2.5,
  });

  static String extractBestImage(Map<String, dynamic> m) {
    final candidates = [
      m['image'],
      m['reciter_image'],
      m['avatar'],
      m['photo'],
      m['img'],
      m['picture'],
    ];
    for (final c in candidates) {
      if (c != null && c.toString().trim().isNotEmpty && c.toString().trim() != 'null') {
        String s = c.toString().trim();
        // If someone stored a relative PHP upload path like "reciter.jpg" or "uploads/reciter.jpg"
        if (!s.startsWith('http://') &&
            !s.startsWith('https://') &&
            !s.startsWith('data:image') &&
            !File(s).existsSync()) {
          if (s.startsWith('uploads/')) {
            s = 'https://quran1.kesug.com/$s';
          } else {
            s = 'https://quran1.kesug.com/uploads/$s';
          }
        }
        return s;
      }
    }
    return '';
  }

  @override
  Widget build(BuildContext context) {
    final src = extractBestImage(data);
    Widget inner;

    if (src.isEmpty) {
      inner = _fallback();
    } else if (src.startsWith('data:image')) {
      try {
        final bytes = base64Decode(src.split(',').last);
        inner = Image.memory(
          bytes,
          width: size,
          height: size,
          fit: BoxFit.cover,
          errorBuilder: (_, __, ___) => _fallback(),
        );
      } catch (_) {
        inner = _fallback();
      }
    } else if (File(src).existsSync()) {
      inner = Image.file(
        File(src),
        width: size,
        height: size,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => _fallback(),
      );
    } else {
      inner = Image.network(
        src,
        width: size,
        height: size,
        fit: BoxFit.cover,
        headers: const {
          'User-Agent': 'Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
          'Accept': 'image/avif,image/webp,image/apng,image/*,*/*;q=0.8',
        },
        loadingBuilder: (context, child, progress) {
          if (progress == null) return child;
          return _fallback();
        },
        errorBuilder: (_, __, ___) => _fallback(),
      );
    }

    return Container(
      width: size,
      height: size,
      padding: EdgeInsets.all(borderWidth),
      decoration: const BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(
          colors: [Color(0xFFC9A959), Color(0xFFA8893A)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        boxShadow: [
          BoxShadow(color: Colors.black45, blurRadius: 8, offset: Offset(0, 3)),
        ],
      ),
      child: ClipOval(
        child: Container(
          color: const Color(0xFF0A0F1E),
          child: inner,
        ),
      ),
    );
  }

  Widget _fallback() {
    return Container(
      width: size,
      height: size,
      color: const Color(0xFF0D2B35),
      child: Icon(Icons.person_rounded, color: const Color(0xFFC9A959), size: size * 0.48),
    );
  }
}

// ============================================================================
// 4. OFFLINE DOWNLOAD MANAGER
// ============================================================================
class OfflineAudioManager extends ChangeNotifier {
  static final OfflineAudioManager instance = OfflineAudioManager._();
  OfflineAudioManager._();

  final Dio _dio = Dio();
  final Map<String, double> progressMap = {};
  List<Map<String, dynamic>> tracks = [];

  Future<void> init() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString('offline_tracks_v5');
      if (raw != null) {
        final decoded = jsonDecode(raw) as List;
        tracks = decoded.cast<Map<String, dynamic>>();
        tracks.removeWhere((e) => !File(e['localPath'] ?? '').existsSync());
        await _save();
      }
      notifyListeners();
    } catch (_) {}
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('offline_tracks_v5', jsonEncode(tracks));
  }

  bool isSaved(String id) => tracks.any((e) => e['id'] == id);

  String? localPathOf(String id) {
    final m = tracks.where((e) => e['id'] == id).toList();
    return m.isEmpty ? null : m.first['localPath'] as String?;
  }

  Future<void> downloadTrack({
    required String id,
    required String title,
    required String reciter,
    required String url,
  }) async {
    if (progressMap.containsKey(id) || url.isEmpty) return;
    try {
      final base = await getApplicationDocumentsDirectory();
      final folder = Directory('${base.path}/quranak_offline_v5');
      if (!folder.existsSync()) folder.createSync(recursive: true);

      final safeId = id.replaceAll(RegExp(r'[^a-zA-Z0-9_-]'), '_');
      final dest = '${folder.path}/$safeId.mp3';

      progressMap[id] = 0.05;
      notifyListeners();

      await _dio.download(
        url,
        dest,
        options: Options(headers: {'User-Agent': 'Mozilla/5.0'}),
        onReceiveProgress: (rec, total) {
          if (total > 0) {
            progressMap[id] = rec / total;
            notifyListeners();
          }
        },
      );

      tracks.removeWhere((e) => e['id'] == id);
      tracks.insert(0, {'id': id, 'title': title, 'reciter': reciter, 'localPath': dest});
      await _save();
    } finally {
      progressMap.remove(id);
      notifyListeners();
    }
  }
}

// ============================================================================
// 5. EGYPTIAN CITIES & 114 SURAHS METADATA (مطابق لـ index.php)
// ============================================================================
class CityInfo {
  final String ar;
  final double lat;
  final double lng;
  const CityInfo(this.ar, this.lat, this.lng);
}

const List<CityInfo> egyptianCities = [
  CityInfo('القاهرة', 30.0444, 31.2357),
  CityInfo('الإسكندرية', 31.2001, 29.9187),
  CityInfo('الجيزة', 30.0131, 31.2089),
  CityInfo('القليوبية', 30.4590, 31.1786),
  CityInfo('بورسعيد', 31.2653, 32.3019),
  CityInfo('السويس', 29.9668, 32.5498),
  CityInfo('الأقصر', 25.6872, 32.6396),
  CityInfo('أسوان', 24.0889, 32.8998),
  CityInfo('الغربية', 30.8754, 31.0335),
  CityInfo('الدقهلية', 31.0409, 31.3785),
  CityInfo('الشرقية', 30.5877, 31.5020),
  CityInfo('الإسماعيلية', 30.5965, 32.2715),
  CityInfo('كفر الشيخ', 31.1107, 30.9388),
  CityInfo('أسيوط', 27.1783, 31.1859),
  CityInfo('بني سويف', 29.0661, 31.0994),
  CityInfo('الفيوم', 29.3084, 30.8428),
  CityInfo('دمياط', 31.4175, 31.8144),
  CityInfo('البحيرة', 31.0341, 30.4682),
  CityInfo('المنيا', 28.0871, 30.7618),
  CityInfo('قنا', 26.1551, 32.7160),
  CityInfo('سوهاج', 26.5591, 31.6957),
  CityInfo('البحر الأحمر', 27.2579, 33.8116),
  CityInfo('مطروح', 31.3543, 27.2373),
  CityInfo('المنوفية', 30.5972, 30.9876),
];

const List<Map<String, dynamic>> all114Surahs = [
  {"n": 1, "name": "سُورَةُ ٱلْفَاتِحَةِ", "plain": "الفاتحة", "ayahs": 7, "page": 1},
  {"n": 2, "name": "سُورَةُ البَقَرَةِ", "plain": "البقرة", "ayahs": 286, "page": 2},
  {"n": 3, "name": "سُورَةُ آلِ عِمْرَانَ", "plain": "آل عمران", "ayahs": 200, "page": 50},
  {"n": 4, "name": "سُورَةُ النِّسَاءِ", "plain": "النساء", "ayahs": 176, "page": 77},
  {"n": 5, "name": "سُورَةُ المَائِدَةِ", "plain": "المائدة", "ayahs": 120, "page": 106},
  {"n": 6, "name": "سُورَةُ الأَنْعَامِ", "plain": "الأنعام", "ayahs": 165, "page": 128},
  {"n": 7, "name": "سُورَةُ الأَعْرَافِ", "plain": "الأعراف", "ayahs": 206, "page": 151},
  {"n": 8, "name": "سُورَةُ الأَنْفَالِ", "plain": "الأنفال", "ayahs": 75, "page": 177},
  {"n": 9, "name": "سُورَةُ التَّوْبَةِ", "plain": "التوبة", "ayahs": 129, "page": 187},
  {"n": 10, "name": "سُورَةُ يُونُسَ", "plain": "يونس", "ayahs": 109, "page": 209},
  {"n": 11, "name": "سُورَةُ هُودٍ", "plain": "هود", "ayahs": 123, "page": 221},
  {"n": 12, "name": "سُورَةُ يُوسُفَ", "plain": "يوسف", "ayahs": 111, "page": 235},
  {"n": 13, "name": "سُورَةُ الرَّعْدِ", "plain": "الرعد", "ayahs": 43, "page": 249},
  {"n": 14, "name": "سُورَةُ إِبْرَاهِيمَ", "plain": "إبراهيم", "ayahs": 52, "page": 255},
  {"n": 15, "name": "سُورَةُ الحِجْرِ", "plain": "الحجر", "ayahs": 99, "page": 262},
  {"n": 16, "name": "سُورَةُ النَّحْلِ", "plain": "النحل", "ayahs": 128, "page": 267},
  {"n": 17, "name": "سُورَةُ الإِسْرَاءِ", "plain": "الإسراء", "ayahs": 111, "page": 282},
  {"n": 18, "name": "سُورَةُ الكَهْفِ", "plain": "الكهف", "ayahs": 110, "page": 293},
  {"n": 19, "name": "سُورَةُ مَرْيَمَ", "plain": "مريم", "ayahs": 98, "page": 305},
  {"n": 20, "name": "سُورَةُ طه", "plain": "طه", "ayahs": 135, "page": 312},
  {"n": 21, "name": "سُورَةُ الأَنْبِيَاءِ", "plain": "الأنبياء", "ayahs": 112, "page": 322},
  {"n": 22, "name": "سُورَةُ الحَجِّ", "plain": "الحج", "ayahs": 78, "page": 332},
  {"n": 23, "name": "سُورَةُ المُؤْمِنُونَ", "plain": "المؤمنون", "ayahs": 118, "page": 342},
  {"n": 24, "name": "سُورَةُ النُّورِ", "plain": "النور", "ayahs": 64, "page": 350},
  {"n": 25, "name": "سُورَةُ الفُرْقَانِ", "plain": "الفرقان", "ayahs": 77, "page": 359},
  {"n": 26, "name": "سُورَةُ الشُّعَرَاءِ", "plain": "الشعراء", "ayahs": 227, "page": 367},
  {"n": 27, "name": "سُورَةُ النَّمْلِ", "plain": "النمل", "ayahs": 93, "page": 377},
  {"n": 28, "name": "سُورَةُ القَصَصِ", "plain": "القصص", "ayahs": 88, "page": 385},
  {"n": 29, "name": "سُورَةُ العَنْكَبُوتِ", "plain": "العنكبوت", "ayahs": 69, "page": 396},
  {"n": 30, "name": "سُورَةُ الرُّومِ", "plain": "الروم", "ayahs": 60, "page": 404},
  {"n": 31, "name": "سُورَةُ لُقْمَانَ", "plain": "لقمان", "ayahs": 34, "page": 411},
  {"n": 32, "name": "سُورَةُ السَّجْدَةِ", "plain": "السجدة", "ayahs": 30, "page": 415},
  {"n": 33, "name": "سُورَةُ الأَحْزَابِ", "plain": "الأحزاب", "ayahs": 73, "page": 418},
  {"n": 34, "name": "سُورَةُ سَبَإٍ", "plain": "سبإ", "ayahs": 54, "page": 428},
  {"n": 35, "name": "سُورَةُ فَاطِرٍ", "plain": "فاطر", "ayahs": 45, "page": 434},
  {"n": 36, "name": "سُورَةُ يس", "plain": "يس", "ayahs": 83, "page": 440},
  {"n": 37, "name": "سُورَةُ الصَّافَّاتِ", "plain": "الصافات", "ayahs": 182, "page": 446},
  {"n": 38, "name": "سُورَةُ ص", "plain": "ص", "ayahs": 88, "page": 453},
  {"n": 39, "name": "سُورَةُ الزُّمَرِ", "plain": "الزمر", "ayahs": 75, "page": 458},
  {"n": 40, "name": "سُورَةُ غَافِرٍ", "plain": "غافر", "ayahs": 85, "page": 467},
  {"n": 41, "name": "سُورَةُ فُصِّلَتْ", "plain": "فصلت", "ayahs": 54, "page": 477},
  {"n": 42, "name": "سُورَةُ الشُّورَىٰ", "plain": "الشورى", "ayahs": 53, "page": 483},
  {"n": 43, "name": "سُورَةُ الزُّخْرُفِ", "plain": "الزخرف", "ayahs": 89, "page": 489},
  {"n": 44, "name": "سُورَةُ الدُّخَانِ", "plain": "الدخان", "ayahs": 59, "page": 496},
  {"n": 45, "name": "سُورَةُ الجَاثِيَةِ", "plain": "الجاثية", "ayahs": 37, "page": 499},
  {"n": 46, "name": "سُورَةُ الأَحْقَافِ", "plain": "الأحقاف", "ayahs": 35, "page": 502},
  {"n": 47, "name": "سُورَةُ مُحَمَّدٍ", "plain": "محمد", "ayahs": 38, "page": 507},
  {"n": 48, "name": "سُورَةُ الفَتْحِ", "plain": "الفتح", "ayahs": 29, "page": 511},
  {"n": 49, "name": "سُورَةُ الحُجُرَاتِ", "plain": "الحجرات", "ayahs": 18, "page": 515},
  {"n": 50, "name": "سُورَةُ ق", "plain": "ق", "ayahs": 45, "page": 518},
  {"n": 51, "name": "سُورَةُ الذَّارِيَاتِ", "plain": "الذاريات", "ayahs": 60, "page": 520},
  {"n": 52, "name": "سُورَةُ الطُّورِ", "plain": "الطور", "ayahs": 49, "page": 523},
  {"n": 53, "name": "سُورَةُ النَّجْمِ", "plain": "النجم", "ayahs": 62, "page": 526},
  {"n": 54, "name": "سُورَةُ القَمَرِ", "plain": "القمر", "ayahs": 55, "page": 528},
  {"n": 55, "name": "سُورَةُ الرَّحْمَٰن", "plain": "الرحمن", "ayahs": 78, "page": 531},
  {"n": 56, "name": "سُورَةُ الوَاقِعَةِ", "plain": "الواقعة", "ayahs": 96, "page": 534},
  {"n": 57, "name": "سُورَةُ الحَدِيدِ", "plain": "الحديد", "ayahs": 29, "page": 537},
  {"n": 58, "name": "سُورَةُ المُجَادَلَةِ", "plain": "المجادلة", "ayahs": 22, "page": 542},
  {"n": 59, "name": "سُورَةُ الحَشْرِ", "plain": "الحشر", "ayahs": 24, "page": 545},
  {"n": 60, "name": "سُورَةُ المُمْتَحَنَةِ", "plain": "الممتحنة", "ayahs": 13, "page": 549},
  {"n": 61, "name": "سُورَةُ الصَّفِّ", "plain": "الصف", "ayahs": 14, "page": 551},
  {"n": 62, "name": "سُورَةُ الجُمُعَةِ", "plain": "الجمعة", "ayahs": 11, "page": 553},
  {"n": 63, "name": "سُورَةُ المُنَافِقُونَ", "plain": "المنافقون", "ayahs": 11, "page": 554},
  {"n": 64, "name": "سُورَةُ التَّغَابُنِ", "plain": "التغابن", "ayahs": 18, "page": 556},
  {"n": 65, "name": "سُورَةُ الطَّلَاقِ", "plain": "الطلاق", "ayahs": 12, "page": 558},
  {"n": 66, "name": "سُورَةُ التَّحْرِيمِ", "plain": "التحريم", "ayahs": 12, "page": 560},
  {"n": 67, "name": "سُورَةُ المُلْكِ", "plain": "الملك", "ayahs": 30, "page": 562},
  {"n": 68, "name": "سُورَةُ القَلَمِ", "plain": "القلم", "ayahs": 52, "page": 564},
  {"n": 69, "name": "سُورَةُ الحَاقَّةِ", "plain": "الحاقة", "ayahs": 52, "page": 566},
  {"n": 70, "name": "سُورَةُ المَعَارِجِ", "plain": "المعارج", "ayahs": 44, "page": 568},
  {"n": 71, "name": "سُورَةُ نُوحٍ", "plain": "نوح", "ayahs": 28, "page": 570},
  {"n": 72, "name": "سُورَةُ الجِنِّ", "plain": "الجن", "ayahs": 28, "page": 572},
  {"n": 73, "name": "سُورَةُ المُزَّمِّلِ", "plain": "المزمل", "ayahs": 20, "page": 574},
  {"n": 74, "name": "سُورَةُ المُدَّثِّرِ", "plain": "المدثر", "ayahs": 56, "page": 575},
  {"n": 75, "name": "سُورَةُ القِيَامَةِ", "plain": "القيامة", "ayahs": 40, "page": 577},
  {"n": 76, "name": "سُورَةُ الإِنْسَانِ", "plain": "الإنسان", "ayahs": 31, "page": 578},
  {"n": 77, "name": "سُورَةُ المُرْسَلَاتِ", "plain": "المرسلات", "ayahs": 50, "page": 580},
  {"n": 78, "name": "سُورَةُ النَّبَإِ", "plain": "النبإ", "ayahs": 40, "page": 581},
  {"n": 79, "name": "سُورَةُ النَّازِعَاتِ", "plain": "النازعات", "ayahs": 46, "page": 583},
  {"n": 80, "name": "سُورَةُ عَبَسَ", "plain": "عبس", "ayahs": 42, "page": 584},
  {"n": 81, "name": "سُورَةُ التَّكْوِيرِ", "plain": "التكوير", "ayahs": 29, "page": 585},
  {"n": 82, "name": "سُورَةُ الانْفِطَارِ", "plain": "الانفطار", "ayahs": 19, "page": 586},
  {"n": 83, "name": "سُورَةُ المُطَفِّفِينَ", "plain": "المطففين", "ayahs": 36, "page": 587},
  {"n": 84, "name": "سُورَةُ الانْشِقَاقِ", "plain": "الانشقاق", "ayahs": 25, "page": 589},
  {"n": 85, "name": "سُورَةُ البُرُوجِ", "plain": "البروج", "ayahs": 22, "page": 590},
  {"n": 86, "name": "سُورَةُ الطَّارِقِ", "plain": "الطارق", "ayahs": 17, "page": 591},
  {"n": 87, "name": "سُورَةُ الأَعْلَىٰ", "plain": "الأعلى", "ayahs": 19, "page": 591},
  {"n": 88, "name": "سُورَةُ الغَاشِيَةِ", "plain": "الغاشية", "ayahs": 26, "page": 592},
  {"n": 89, "name": "سُورَةُ الفَجْرِ", "plain": "الفجر", "ayahs": 30, "page": 593},
  {"n": 90, "name": "سُورَةُ البَلَدِ", "plain": "البلد", "ayahs": 20, "page": 594},
  {"n": 91, "name": "سُورَةُ الشَّمْسِ", "plain": "الشمس", "ayahs": 15, "page": 595},
  {"n": 92, "name": "سُورَةُ اللَّيْلِ", "plain": "الليل", "ayahs": 21, "page": 595},
  {"n": 93, "name": "سُورَةُ الضُّحَىٰ", "plain": "الضحى", "ayahs": 11, "page": 596},
  {"n": 94, "name": "سُورَةُ الشَّرْحِ", "plain": "الشرح", "ayahs": 8, "page": 596},
  {"n": 95, "name": "سُورَةُ التِّينِ", "plain": "التين", "ayahs": 8, "page": 597},
  {"n": 96, "name": "سُورَةُ العَلَقِ", "plain": "العلق", "ayahs": 19, "page": 597},
  {"n": 97, "name": "سُورَةُ القَدْرِ", "plain": "القدر", "ayahs": 5, "page": 598},
  {"n": 98, "name": "سُورَةُ البَيِّنَةِ", "plain": "البينة", "ayahs": 8, "page": 598},
  {"n": 99, "name": "سُورَةُ الزَّلْزَلَةِ", "plain": "الزلزلة", "ayahs": 8, "page": 599},
  {"n": 100, "name": "سُورَةُ العَادِيَاتِ", "plain": "العاديات", "ayahs": 11, "page": 599},
  {"n": 101, "name": "سُورَةُ القَارِعَةِ", "plain": "القارعة", "ayahs": 11, "page": 600},
  {"n": 102, "name": "سُورَةُ التَّكَاثُرِ", "plain": "التكاثر", "ayahs": 8, "page": 600},
  {"n": 103, "name": "سُورَةُ العَصْرِ", "plain": "العصر", "ayahs": 3, "page": 601},
  {"n": 104, "name": "سُورَةُ الهُمَزَةِ", "plain": "الهمزة", "ayahs": 9, "page": 601},
  {"n": 105, "name": "سُورَةُ الفِيلِ", "plain": "الفيل", "ayahs": 5, "page": 601},
  {"n": 106, "name": "سُورَةُ قُرَيْشٍ", "plain": "قريش", "ayahs": 4, "page": 602},
  {"n": 107, "name": "سُورَةُ المَاعُونِ", "plain": "الماعون", "ayahs": 7, "page": 602},
  {"n": 108, "name": "سُورَةُ الكَوْثَرِ", "plain": "الكوثر", "ayahs": 3, "page": 602},
  {"n": 109, "name": "سُورَةُ الكَافِرُونَ", "plain": "الكافرون", "ayahs": 6, "page": 603},
  {"n": 110, "name": "سُورَةُ النَّصْرِ", "plain": "النصر", "ayahs": 3, "page": 603},
  {"n": 111, "name": "سُورَةُ المَسَدِ", "plain": "المسد", "ayahs": 5, "page": 603},
  {"n": 112, "name": "سُورَةُ الإِخْلَاصِ", "plain": "الإخلاص", "ayahs": 4, "page": 604},
  {"n": 113, "name": "سُورَةُ الفَلَقِ", "plain": "الفلق", "ayahs": 5, "page": 604},
  {"n": 114, "name": "سُورَةُ النَّاسِ", "plain": "الناس", "ayahs": 6, "page": 604},
];

// ============================================================================
// 6. ROOT APP & ORIGINAL 5-TAB NAVIGATION (الرئيسية - القرآن - أجزاء - صوتيات - ريلز)
// ============================================================================
class QuranakApp extends StatelessWidget {
  const QuranakApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      navigatorKey: navigatorKey,
      title: 'قرآنك',
      debugShowCheckedModeBanner: false,
      locale: const Locale('ar', 'EG'),
      supportedLocales: const [Locale('ar', 'EG'), Locale('ar')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF07131C),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFFC9A959),
          secondary: Color(0xFF0D2B35),
          surface: Color(0xFF0F2B3D),
        ),
        useMaterial3: true,
      ),
      home: const OriginalMainShell(),
    );
  }
}

class OriginalMainShell extends StatefulWidget {
  const OriginalMainShell({super.key});

  @override
  State<OriginalMainShell> createState() => _OriginalMainShellState();
}

class _OriginalMainShellState extends State<OriginalMainShell> {
  int _tabIndex = 0; // 0: الرئيسية, 1: القرآن, 2: أجزاء, 3: صوتيات, 4: ريلز
  CityInfo _selectedCity = egyptianCities.first;
  Map<String, DateTime> _prayerTimes = {};
  Timer? _countdownTimer;
  String _nextPrayerName = 'العصر';
  String _nextPrayerKey = 'Asr';
  String _countdownStr = '--:--:--';

  final AudioPlayer _audioPlayer = AudioPlayer();
  String _playingSurah = '';
  String _playingReciter = '';
  Map<String, dynamic> _playingReciterData = {};
  bool _isPlaying = false;
  StreamSubscription? _adminSub;
  String? _lastNotifId;

  @override
  void initState() {
    super.initState();
    _audioPlayer.playerStateStream.listen((s) {
      if (mounted) setState(() => _isPlaying = s.playing);
    });
    _initEverything();
  }

  Future<void> _initEverything() async {
    await OfflineAudioManager.instance.init();
    final prefs = await SharedPreferences.getInstance();
    final savedCity = prefs.getString('selectedCity') ?? 'القاهرة';
    _selectedCity = egyptianCities.firstWhere(
      (c) => c.ar == savedCity,
      orElse: () => egyptianCities.first,
    );
    await _refreshCityAndAdhan(_selectedCity);
    _listenAdminBroadcasts();
  }

  Future<void> _refreshCityAndAdhan(CityInfo city) async {
    _selectedCity = city;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('selectedCity', city.ar);
    final times = await AdhanAlarmService.schedule7DaysForCity(city.lat, city.lng, city.ar);
    if (mounted) {
      setState(() => _prayerTimes = times);
      _startLiveCountdown();
    }
  }

  void _startLiveCountdown() {
    _countdownTimer?.cancel();
    void tick() {
      if (_prayerTimes.isEmpty) return;
      final now = DateTime.now();
      final order = [
        MapEntry('Fajr', 'الفجر'),
        MapEntry('Sunrise', 'الشروق'),
        MapEntry('Dhuhr', 'الظهر'),
        MapEntry('Asr', 'العصر'),
        MapEntry('Maghrib', 'المغرب'),
        MapEntry('Isha', 'العشاء'),
      ];
      DateTime? target;
      String tName = 'الفجر';
      String tKey = 'Fajr';

      for (final item in order) {
        final dt = _prayerTimes[item.key];
        if (dt != null && dt.isAfter(now)) {
          target = dt;
          tName = item.value;
          tKey = item.key;
          break;
        }
      }
      if (target == null && _prayerTimes['Fajr'] != null) {
        target = _prayerTimes['Fajr']!.add(const Duration(days: 1));
        tName = 'الفجر';
        tKey = 'Fajr';
      }
      if (target != null && mounted) {
        final diff = target.difference(now);
        final h = diff.inHours.toString().padLeft(2, '0');
        final m = (diff.inMinutes % 60).toString().padLeft(2, '0');
        final s = (diff.inSeconds % 60).toString().padLeft(2, '0');
        setState(() {
          _nextPrayerName = tName;
          _nextPrayerKey = tKey;
          _countdownStr = '$h : $m : $s';
        });
      }
    }

    tick();
    _countdownTimer = Timer.periodic(const Duration(seconds: 1), (_) => tick());
  }

  void _listenAdminBroadcasts() {
    try {
      _adminSub = FirebaseFirestore.instance
          .collection('admin_notifications')
          .orderBy('createdAt', descending: true)
          .limit(1)
          .snapshots()
          .listen((snap) async {
        if (snap.docs.isEmpty) return;
        final doc = snap.docs.first;
        final prefs = await SharedPreferences.getInstance();
        final seen = prefs.getString('last_admin_notif_v5');
        if (doc.id != seen && doc.id != _lastNotifId) {
          _lastNotifId = doc.id;
          await prefs.setString('last_admin_notif_v5', doc.id);
          final d = doc.data();
          await AdhanAlarmService.showAdminBroadcast(
            d['title'] ?? 'قرآنك',
            d['body'] ?? '',
          );
        }
      });
    } catch (_) {}
  }

  Future<void> _playSurahAudio({
    required String id,
    required String title,
    required String reciter,
    required Map<String, dynamic> reciterData,
    required String url,
  }) async {
    try {
      setState(() {
        _playingSurah = title;
        _playingReciter = reciter;
        _playingReciterData = reciterData;
      });
      final local = OfflineAudioManager.instance.localPathOf(id);
      if (local != null && File(local).existsSync()) {
        await _audioPlayer.setFilePath(local);
      } else {
        await _audioPlayer.setUrl(url);
      }
      await _audioPlayer.play();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر تشغيل الصوت: $e')));
      }
    }
  }

  @override
  void dispose() {
    _countdownTimer?.cancel();
    _adminSub?.cancel();
    _audioPlayer.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      OriginalHomeTab(
        selectedCity: _selectedCity,
        onCityChanged: _refreshCityAndAdhan,
        prayerTimes: _prayerTimes,
        nextPrayerName: _nextPrayerName,
        nextPrayerKey: _nextPrayerKey,
        countdownStr: _countdownStr,
        onSwitchTab: (i) => setState(() => _tabIndex = i),
        onPlayAudio: _playSurahAudio,
      ),
      const OriginalQuranSurahsTab(),
      const OriginalJuzTab(),
      OriginalAudiosTab(onPlayAudio: _playSurahAudio),
      const OriginalReelsTab(),
    ];

    return Scaffold(
      backgroundColor: const Color(0xFF07131C),
      body: IndexedStack(index: _tabIndex, children: pages),
      bottomNavigationBar: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (_playingSurah.isNotEmpty)
            Container(
              height: 58,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              decoration: const BoxDecoration(
                gradient: LinearGradient(colors: [Color(0xFF1A3A4A), Color(0xFF0F2530)]),
                border: Border(top: BorderSide(color: Color(0xFFC9A959), width: 0.8)),
              ),
              child: Row(
                children: [
                  ReciterAvatarImage(data: _playingReciterData, size: 40, borderWidth: 1.5),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(_playingSurah, maxLines: 1, overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: Colors.white)),
                        Text(_playingReciter, style: const TextStyle(fontSize: 11, color: Colors.white60)),
                      ],
                    ),
                  ),
                  IconButton(
                    icon: Icon(_isPlaying ? Icons.pause_circle_filled : Icons.play_circle_fill,
                        color: Colors.white, size: 34),
                    onPressed: () => _isPlaying ? _audioPlayer.pause() : _audioPlayer.play(),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close, color: Colors.white70, size: 20),
                    onPressed: () {
                      _audioPlayer.stop();
                      setState(() => _playingSurah = '');
                    },
                  ),
                ],
              ),
            ),
          Container(
            decoration: const BoxDecoration(
              color: Color(0xFF0F2B3D),
              border: Border(top: BorderSide(color: Color(0xFFC9A959), width: 0.9)),
            ),
            child: BottomNavigationBar(
              currentIndex: _tabIndex,
              onTap: (i) => setState(() => _tabIndex = i),
              backgroundColor: const Color(0xFF0F2B3D),
              type: BottomNavigationBarType.fixed,
              selectedItemColor: const Color(0xFFC9A959),
              unselectedItemColor: const Color(0xFF7F8C8D),
              selectedFontSize: 11,
              unselectedFontSize: 10,
              items: const [
                BottomNavigationBarItem(icon: Icon(Icons.home_rounded), label: 'الرئيسية'),
                BottomNavigationBarItem(icon: Icon(Icons.menu_book_rounded), label: 'القرآن'),
                BottomNavigationBarItem(icon: Icon(Icons.grid_view_rounded), label: 'أجزاء'),
                BottomNavigationBarItem(icon: Icon(Icons.headphones_rounded), label: 'صوتيات'),
                BottomNavigationBarItem(icon: Icon(Icons.movie_filter_rounded), label: 'ريلز'),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================================
// 7. ORIGINAL HOME TAB (مطابق تماماً للصورة الأولى + index.php)
// ============================================================================
class OriginalHomeTab extends StatelessWidget {
  final CityInfo selectedCity;
  final ValueChanged<CityInfo> onCityChanged;
  final Map<String, DateTime> prayerTimes;
  final String nextPrayerName;
  final String nextPrayerKey;
  final String countdownStr;
  final ValueChanged<int> onSwitchTab;
  final Function({required String id, required String title, required String reciter, required Map<String, dynamic> reciterData, required String url}) onPlayAudio;

  const OriginalHomeTab({
    super.key,
    required this.selectedCity,
    required this.onCityChanged,
    required this.prayerTimes,
    required this.nextPrayerName,
    required this.nextPrayerKey,
    required this.countdownStr,
    required this.onSwitchTab,
    required this.onPlayAudio,
  });

  String _fmt12(DateTime? dt) {
    if (dt == null) return '--:--';
    final h = dt.hour % 12 == 0 ? 12 : dt.hour % 12;
    final m = dt.minute.toString().padLeft(2, '0');
    final suf = dt.hour >= 12 ? 'م' : 'ص';
    return '$h:$m $suf';
  }

  String _heroBgForPrayer(String key) {
    switch (key) {
      case 'Fajr':
        return 'https://quran1.kesug.com/20.png';
      case 'Sunrise':
        return 'https://quran1.kesug.com/22.png';
      case 'Maghrib':
        return 'https://quran1.kesug.com/24.png';
      case 'Isha':
        return 'https://quran1.kesug.com/23.png';
      default:
        return 'https://quran1.kesug.com/21.png';
    }
  }

  @override
  Widget build(BuildContext context) {
    final hijri = HijriCalendar.now();
    final hijriStr = '${hijri.hDay} ${hijri.longMonthName} ${hijri.hYear} هـ';

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // 1. PRAYER HERO (نفس تصميم الهيرو في الصورة الأولى مع الخلفية الطبيعية والعد التنازلي)
          Container(
            height: 295,
            width: double.infinity,
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFF0A2A25), Color(0xFF071915)],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
            ),
            child: Stack(
              fit: StackFit.expand,
              children: [
                Image.network(
                  _heroBgForPrayer(nextPrayerKey),
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => const SizedBox.shrink(),
                ),
                Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        const Color(0xFF07131C).withOpacity(0.45),
                        const Color(0xFF07131C).withOpacity(0.28),
                        const Color(0xFF07131C).withOpacity(0.85),
                      ],
                    ),
                  ),
                ),
                SafeArea(
                  bottom: false,
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(14, 10, 14, 14),
                    child: Column(
                      children: [
                        // Top Row: المدينة + التاريخ الهجري
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            GestureDetector(
                              onTap: () => _openCityDialog(context),
                              child: Container(
                                padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 7),
                                decoration: BoxDecoration(
                                  color: Colors.black.withOpacity(0.42),
                                  borderRadius: BorderRadius.circular(30),
                                  border: Border.all(color: Colors.white.withOpacity(0.16)),
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    const Icon(Icons.location_on_rounded, color: Color(0xFFC9A959), size: 15),
                                    const SizedBox(width: 5),
                                    Text(selectedCity.ar, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                                    const SizedBox(width: 4),
                                    const Icon(Icons.keyboard_arrow_down_rounded, size: 16, color: Colors.white70),
                                  ],
                                ),
                              ),
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 7),
                              decoration: BoxDecoration(
                                color: Colors.black.withOpacity(0.42),
                                borderRadius: BorderRadius.circular(30),
                                border: Border.all(color: Colors.white.withOpacity(0.16)),
                              ),
                              child: Text(hijriStr, style: const TextStyle(fontSize: 12, color: Colors.white)),
                            ),
                          ],
                        ),
                        const Spacer(),
                        // Center Countdown: المتبقي على صلاة ... + العداد الكبير
                        RichText(
                          text: TextSpan(
                            style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: Colors.white),
                            children: [
                              const TextSpan(text: 'المتبقي على صلاة '),
                              TextSpan(
                                text: nextPrayerName,
                                style: const TextStyle(color: Color(0xFFC9A959), fontWeight: FontWeight.w900),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 6),
                        Directionality(
                          textDirection: TextDirection.ltr,
                          child: Text(
                            countdownStr,
                            style: const TextStyle(
                              fontSize: 38,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 2,
                              color: Colors.white,
                              shadows: [Shadow(color: Colors.black87, blurRadius: 18)],
                            ),
                          ),
                        ),
                        const Spacer(),
                        // Bottom 6 Prayer Columns (الفجر - الشروق - الظهر - العصر - المغرب - العشاء)
                        Container(
                          padding: const EdgeInsets.symmetric(vertical: 9, horizontal: 4),
                          decoration: BoxDecoration(
                            color: Colors.black.withOpacity(0.48),
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(color: Colors.white.withOpacity(0.12)),
                          ),
                          child: Row(
                            children: [
                              _prayerCol('الفجر', _fmt12(prayerTimes['Fajr']), nextPrayerKey == 'Fajr'),
                              _prayerCol('الشروق', _fmt12(prayerTimes['Sunrise']), nextPrayerKey == 'Sunrise'),
                              _prayerCol('الظهر', _fmt12(prayerTimes['Dhuhr']), nextPrayerKey == 'Dhuhr'),
                              _prayerCol('العصر', _fmt12(prayerTimes['Asr']), nextPrayerKey == 'Asr'),
                              _prayerCol('المغرب', _fmt12(prayerTimes['Maghrib']), nextPrayerKey == 'Maghrib'),
                              _prayerCol('العشاء', _fmt12(prayerTimes['Isha']), nextPrayerKey == 'Isha'),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),

          // 2. القراء (نفس الشريط الدائري الذهبي في الصورة الأولى)
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 18, 16, 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Row(
                  children: [
                    Icon(Icons.mic_rounded, color: Color(0xFFC9A959), size: 20),
                    SizedBox(width: 6),
                    Text('القراء', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900, color: Color(0xFFC9A959))),
                  ],
                ),
                GestureDetector(
                  onTap: () => onSwitchTab(3),
                  child: const Row(
                    children: [
                      Text('عرض الكل', style: TextStyle(fontSize: 12, color: Color(0xFFA0B9C4))),
                      SizedBox(width: 4),
                      Icon(Icons.chevron_right_rounded, size: 16, color: Color(0xFFA0B9C4)),
                    ],
                  ),
                ),
              ],
            ),
          ),
          SizedBox(
            height: 112,
            child: StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance.collection('reciters').snapshots(),
              builder: (context, snap) {
                final docs = snap.data?.docs ?? [];
                if (docs.isEmpty) {
                  return const Center(child: CircularProgressIndicator(color: Color(0xFFC9A959)));
                }
                return ListView.separated(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  itemCount: docs.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 14),
                  itemBuilder: (context, i) {
                    final r = docs[i].data() as Map<String, dynamic>;
                    final name = (r['name'] ?? '').toString();
                    return GestureDetector(
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => OriginalReciterDetailScreen(
                            reciterData: r,
                            onPlayAudio: onPlayAudio,
                          ),
                        ),
                      ),
                      child: SizedBox(
                        width: 78,
                        child: Column(
                          children: [
                            ReciterAvatarImage(data: r, size: 74, borderWidth: 2.5),
                            const SizedBox(height: 6),
                            Text(
                              name,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.center,
                              style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Colors.white),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),

          // 3. أضيف حديثاً (نفس بطاقات الفيديو الرأسية 9:16 في الصورة الأولى)
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Row(
                  children: [
                    Icon(Icons.access_time_filled_rounded, color: Color(0xFFC9A959), size: 19),
                    SizedBox(width: 6),
                    Text('أضيف حديثاً', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900, color: Color(0xFFC9A959))),
                  ],
                ),
                GestureDetector(
                  onTap: () => onSwitchTab(4),
                  child: const Row(
                    children: [
                      Text('عرض الكل', style: TextStyle(fontSize: 12, color: Color(0xFFA0B9C4))),
                      SizedBox(width: 4),
                      Icon(Icons.chevron_right_rounded, size: 16, color: Color(0xFFA0B9C4)),
                    ],
                  ),
                ),
              ],
            ),
          ),
          SizedBox(
            height: 225,
            child: StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance.collection('videos').limit(10).snapshots(),
              builder: (context, snap) {
                final docs = snap.data?.docs ?? [];
                if (docs.isEmpty) {
                  return const Center(child: Text('لا توجد مقاطع مضافة حديثاً', style: TextStyle(color: Colors.white54)));
                }
                return ListView.separated(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  itemCount: docs.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 12),
                  itemBuilder: (context, i) {
                    final v = docs[i].data() as Map<String, dynamic>;
                    return GestureDetector(
                      onTap: () => onSwitchTab(4),
                      child: Container(
                        width: 132,
                        decoration: BoxDecoration(
                          color: const Color(0xFF0A0F1E),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: const Color(0xFFC9A959).withOpacity(0.35), width: 1.5),
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(14),
                          child: Stack(
                            fit: StackFit.expand,
                            children: [
                              if ((v['thumbnail'] ?? '').toString().isNotEmpty)
                                Image.network(v['thumbnail'], fit: BoxFit.cover, errorBuilder: (_, __, ___) => _videoThumbBg())
                              else
                                _videoThumbBg(),
                              Center(
                                child: Container(
                                  width: 42,
                                  height: 42,
                                  decoration: BoxDecoration(
                                    color: Colors.black54,
                                    shape: BoxShape.circle,
                                    border: Border.all(color: const Color(0xFFC9A959), width: 1.8),
                                  ),
                                  child: const Icon(Icons.play_arrow_rounded, color: Color(0xFFC9A959), size: 24),
                                ),
                              ),
                              Positioned(
                                bottom: 8,
                                right: 8,
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                                  decoration: BoxDecoration(color: Colors.black87, borderRadius: BorderRadius.circular(6)),
                                  child: Text(
                                    (v['duration'] ?? '00:45').toString(),
                                    style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: Colors.white),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),

          // 4. الأيقونات السريعة (الأذكار - المسبحة - الأحاديث - التقويم + تجربة منبه الأذان)
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 20, 16, 24),
            child: GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              mainAxisSpacing: 12,
              crossAxisSpacing: 12,
              childAspectRatio: 2.35,
              children: [
                _quickCard(context, 'الأذكار', Icons.volunteer_activism_rounded, const Color(0xFF10B981),
                    () => Navigator.push(context, MaterialPageRoute(builder: (_) => const OriginalAzkarScreen()))),
                _quickCard(context, 'المسبحة', Icons.radio_button_checked_rounded, const Color(0xFFC9A959),
                    () => Navigator.push(context, MaterialPageRoute(builder: (_) => const OriginalTasbihScreen()))),
                _quickCard(context, 'الأحاديث', Icons.menu_book_rounded, const Color(0xFF38BDF8),
                    () => Navigator.push(context, MaterialPageRoute(builder: (_) => const OriginalHadithScreen()))),
                _quickCard(context, 'التقويم', Icons.calendar_month_rounded, const Color(0xFFF59E0B),
                    () => Navigator.push(context, MaterialPageRoute(builder: (_) => const OriginalCalendarScreen()))),
                _quickCard(context, 'منبه الأذان', Icons.alarm_on_rounded, const Color(0xFFC9A959), () async {
                  await AdhanAlarmService.triggerTestAdhanAlarm(nextPrayerName);
                  if (context.mounted) {
                    Navigator.push(context, MaterialPageRoute(builder: (_) => AdhanAlarmScreen(prayerName: 'صلاة $nextPrayerName')));
                  }
                }),
                _quickCard(context, 'التنزيلات', Icons.download_done_rounded, const Color(0xFF10B981),
                    () => Navigator.push(context, MaterialPageRoute(builder: (_) => OriginalDownloadsScreen(onPlayAudio: onPlayAudio)))),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _prayerCol(String name, String time, bool active) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 4),
        decoration: BoxDecoration(
          color: active ? const Color(0xFFC9A959).withOpacity(0.24) : Colors.transparent,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Column(
          children: [
            Text(
              name,
              style: TextStyle(
                fontSize: 10,
                fontWeight: active ? FontWeight.w900 : FontWeight.w600,
                color: active ? const Color(0xFFC9A959) : Colors.white70,
              ),
            ),
            const SizedBox(height: 3),
            Directionality(
              textDirection: TextDirection.ltr,
              child: Text(
                time,
                style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: Colors.white),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _videoThumbBg() {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFF1A4755), Color(0xFF0D2B35)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: const Center(child: Icon(Icons.mosque_rounded, color: Color(0xFFC9A959), size: 36)),
    );
  }

  Widget _quickCard(BuildContext ctx, String label, IconData icon, Color color, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(18),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14),
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [Color(0xFF1A4755), Color(0xFF0F2B3D)]),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: const Color(0xFFC9A959).withOpacity(0.25), width: 1.5),
        ),
        child: Row(
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: color, width: 2),
                color: color.withOpacity(0.12),
              ),
              child: Icon(icon, color: color, size: 22),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(label, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w900, color: Colors.white)),
            ),
          ],
        ),
      ),
    );
  }

  void _openCityDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF0D2B35),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: const BorderSide(color: Color(0xFFC9A959)),
        ),
        title: const Text('اختر المدينة', style: TextStyle(color: Color(0xFFC9A959), fontWeight: FontWeight.bold)),
        content: SizedBox(
          width: double.maxFinite,
          height: 360,
          child: GridView.builder(
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              mainAxisSpacing: 8,
              crossAxisSpacing: 8,
              childAspectRatio: 2.7,
            ),
            itemCount: egyptianCities.length,
            itemBuilder: (_, i) {
              final c = egyptianCities[i];
              final sel = c.ar == selectedCity.ar;
              return InkWell(
                onTap: () {
                  Navigator.pop(ctx);
                  onCityChanged(c);
                },
                borderRadius: BorderRadius.circular(10),
                child: Container(
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: sel ? const Color(0xFFC9A959) : Colors.white.withOpacity(0.06),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: const Color(0xFFC9A959).withOpacity(0.3)),
                  ),
                  child: Text(
                    c.ar,
                    style: TextStyle(
                      color: sel ? Colors.black : Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 13,
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}

// ============================================================================
// 8. TAB 2: القرآن (مطابق للصورة الثانية: بحث ذهبي + بطاقات السور بالاسم المشكل وعدد الآيات والرقم الذهبي)
// ============================================================================
class OriginalQuranSurahsTab extends StatefulWidget {
  const OriginalQuranSurahsTab({super.key});

  @override
  State<OriginalQuranSurahsTab> createState() => _OriginalQuranSurahsTabState();
}

class _OriginalQuranSurahsTabState extends State<OriginalQuranSurahsTab> {
  String _q = '';

  @override
  Widget build(BuildContext context) {
    final list = all114Surahs.where((s) {
      if (_q.trim().isEmpty) return true;
      return s['plain'].toString().contains(_q.trim()) ||
          s['name'].toString().contains(_q.trim()) ||
          s['n'].toString() == _q.trim();
    }).toList();

    return SafeArea(
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 10),
            child: TextField(
              onChanged: (v) => setState(() => _q = v),
              decoration: InputDecoration(
                hintText: '🔍 ابحث عن سورة...',
                hintStyle: const TextStyle(color: Colors.white38),
                filled: true,
                fillColor: const Color(0xFF07131C),
                contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(30),
                  borderSide: const BorderSide(color: Color(0xFFC9A959), width: 1.8),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(30),
                  borderSide: const BorderSide(color: Color(0xFFC9A959), width: 2),
                ),
              ),
            ),
          ),
          Expanded(
            child: ListView.separated(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 20),
              itemCount: list.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (context, i) {
                final s = list[i];
                return InkWell(
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => MushafPageViewerScreen(
                        initialPage: s['page'] as int,
                        title: s['name'] as String,
                      ),
                    ),
                  ),
                  borderRadius: BorderRadius.circular(14),
                  child: Container(
                    height: 76,
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(colors: [Color(0xFF1A4755), Color(0xFF0F2B3D)]),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: const Color(0xFFC9A959).withOpacity(0.3)),
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 50,
                          height: 50,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(colors: [Color(0xFFC9A959), Color(0xFFA8893A)]),
                            borderRadius: BorderRadius.circular(14),
                          ),
                          child: Text(
                            '${s['n']}',
                            style: const TextStyle(color: Colors.black, fontWeight: FontWeight.w900, fontSize: 19),
                          ),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                s['name'] as String,
                                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
                              ),
                              const SizedBox(height: 2),
                              Text(
                                '${s['ayahs']} آية',
                                style: const TextStyle(fontSize: 12, color: Color(0xFFA0B9C4)),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 50),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class MushafPageViewerScreen extends StatefulWidget {
  final int initialPage;
  final String title;
  const MushafPageViewerScreen({super.key, required this.initialPage, required this.title});

  @override
  State<MushafPageViewerScreen> createState() => _MushafPageViewerScreenState();
}

class _MushafPageViewerScreenState extends State<MushafPageViewerScreen> {
  late PageController _pc;
  late int _page;

  @override
  void initState() {
    super.initState();
    _page = widget.initialPage.clamp(1, 604);
    _pc = PageController(initialPage: _page - 1);
  }

  @override
  void dispose() {
    _pc.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F0E0),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0D2B35),
        title: Text(widget.title, style: const TextStyle(color: Color(0xFFC9A959), fontWeight: FontWeight.bold)),
        actions: [
          Center(
            child: Padding(
              padding: const EdgeInsets.only(left: 14),
              child: Text('$_page / 604', style: const TextStyle(color: Color(0xFFE2C78A), fontWeight: FontWeight.bold)),
            ),
          ),
        ],
      ),
      body: PageView.builder(
        controller: _pc,
        itemCount: 604,
        onPageChanged: (idx) => setState(() => _page = idx + 1),
        itemBuilder: (context, idx) {
          final pNum = (idx + 1).toString().padLeft(3, '0');
          final url = 'https://quran.yousefheiba.com/api/quran-pages/$pNum.png';
          return InteractiveViewer(
            child: Center(
              child: Image.network(
                url,
                fit: BoxFit.contain,
                loadingBuilder: (c, child, prog) =>
                    prog == null ? child : const CircularProgressIndicator(color: Color(0xFFC9A959)),
                errorBuilder: (_, __, ___) => const Text('تعذر تحميل صفحة المصحف', style: TextStyle(color: Colors.black)),
              ),
            ),
          );
        },
      ),
    );
  }
}

// ============================================================================
// 9. TAB 3: أجزاء (مطابق للصورة الثالثة: شبكة 3 أعمدة للأجزاء 1..30 بالرقم الذهبي وكلمة الجزء)
// ============================================================================
class OriginalJuzTab extends StatelessWidget {
  const OriginalJuzTab({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: GridView.builder(
        padding: const EdgeInsets.all(14),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3,
          mainAxisSpacing: 10,
          crossAxisSpacing: 10,
          childAspectRatio: 1.05,
        ),
        itemCount: 30,
        itemBuilder: (context, i) {
          final juz = i + 1;
          final page = ((juz - 1) * 20 + 2).clamp(1, 604);
          return InkWell(
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => MushafPageViewerScreen(initialPage: page, title: 'الجزء $juz'),
              ),
            ),
            borderRadius: BorderRadius.circular(14),
            child: Container(
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [Color(0xFF1A4755), Color(0xFF0F2B3D)]),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: const Color(0xFFC9A959).withOpacity(0.3)),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    '$juz',
                    style: const TextStyle(color: Color(0xFFC9A959), fontSize: 28, fontWeight: FontWeight.w900),
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    'الجزء',
                    style: TextStyle(color: Color(0xFFA0B9C4), fontSize: 12, fontWeight: FontWeight.w600),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

// ============================================================================
// 10. TAB 4: صوتيات (مطابق للصورة الرابعة: بحث + شبكة 2 عمود للقراء بصورهم الدائرية الذهبية)
// ============================================================================
class OriginalAudiosTab extends StatefulWidget {
  final Function({required String id, required String title, required String reciter, required Map<String, dynamic> reciterData, required String url}) onPlayAudio;
  const OriginalAudiosTab({super.key, required this.onPlayAudio});

  @override
  State<OriginalAudiosTab> createState() => _OriginalAudiosTabState();
}

class _OriginalAudiosTabState extends State<OriginalAudiosTab> {
  String _search = '';

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
            child: TextField(
              onChanged: (v) => setState(() => _search = v),
              decoration: InputDecoration(
                hintText: '🔍 ابحث عن قارئ...',
                hintStyle: const TextStyle(color: Colors.white38),
                filled: true,
                fillColor: const Color(0xFF07131C),
                contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(30),
                  borderSide: const BorderSide(color: Color(0xFFC9A959), width: 1.8),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(30),
                  borderSide: const BorderSide(color: Color(0xFFC9A959), width: 2),
                ),
              ),
            ),
          ),
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance.collection('reciters').snapshots(),
              builder: (context, snap) {
                final allDocs = snap.data?.docs ?? [];
                final filtered = allDocs.where((d) {
                  final m = d.data() as Map<String, dynamic>;
                  final n = (m['name'] ?? '').toString();
                  return _search.trim().isEmpty || n.contains(_search.trim());
                }).toList();

                if (filtered.isEmpty) {
                  return const Center(child: Text('لا يوجد قراء', style: TextStyle(color: Colors.white60)));
                }

                return GridView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 20),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    mainAxisSpacing: 14,
                    crossAxisSpacing: 14,
                    childAspectRatio: 1.05,
                  ),
                  itemCount: filtered.length,
                  itemBuilder: (context, i) {
                    final r = filtered[i].data() as Map<String, dynamic>;
                    return InkWell(
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => OriginalReciterDetailScreen(
                            reciterData: r,
                            onPlayAudio: widget.onPlayAudio,
                          ),
                        ),
                      ),
                      borderRadius: BorderRadius.circular(14),
                      child: Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(colors: [Color(0xFF1A4755), Color(0xFF0F2B3D)]),
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(color: const Color(0xFFC9A959).withOpacity(0.25)),
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            ReciterAvatarImage(data: r, size: 80, borderWidth: 3),
                            const SizedBox(height: 10),
                            Text(
                              (r['name'] ?? '').toString(),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                color: Color(0xFFC9A959),
                                fontSize: 15,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class OriginalReciterDetailScreen extends StatelessWidget {
  final Map<String, dynamic> reciterData;
  final Function({required String id, required String title, required String reciter, required Map<String, dynamic> reciterData, required String url}) onPlayAudio;

  const OriginalReciterDetailScreen({
    super.key,
    required this.reciterData,
    required this.onPlayAudio,
  });

  @override
  Widget build(BuildContext context) {
    final name = (reciterData['name'] ?? '').toString();
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF0D2B35),
        title: Row(
          children: [
            ReciterAvatarImage(data: reciterData, size: 38, borderWidth: 1.5),
            const SizedBox(width: 10),
            Expanded(
              child: Text(name, style: const TextStyle(color: Color(0xFFC9A959), fontSize: 16, fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('audios').where('reciter_name', isEqualTo: name).snapshots(),
        builder: (context, snap) {
          final docs = snap.data?.docs ?? [];
          if (docs.isEmpty) {
            return const Center(child: Text('لا توجد سور مضافة لهذا القارئ بعد'));
          }
          return AnimatedBuilder(
            animation: OfflineAudioManager.instance,
            builder: (context, _) {
              return ListView.separated(
                padding: const EdgeInsets.all(14),
                itemCount: docs.length,
                separatorBuilder: (_, __) => const SizedBox(height: 8),
                itemBuilder: (context, i) {
                  final doc = docs[i];
                  final a = doc.data() as Map<String, dynamic>;
                  final id = doc.id;
                  final title = (a['title'] ?? '').toString();
                  final url = (a['audio_url'] ?? '').toString();
                  final saved = OfflineAudioManager.instance.isSaved(id);
                  final prog = OfflineAudioManager.instance.progressMap[id];

                  return Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(
                      color: const Color(0xFF1A4755),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                              Text(saved ? 'محفوظ أوفلاين ✓' : 'رقم ${a['surah_number'] ?? i + 1}',
                                  style: TextStyle(fontSize: 11, color: saved ? Colors.greenAccent : const Color(0xFFA0B9C4))),
                            ],
                          ),
                        ),
                        if (prog != null)
                          SizedBox(
                            width: 24,
                            height: 24,
                            child: CircularProgressIndicator(value: prog, strokeWidth: 2, color: const Color(0xFFC9A959)),
                          )
                        else
                          IconButton(
                            icon: Icon(
                              saved ? Icons.download_done_rounded : Icons.download_rounded,
                              color: Colors.white,
                            ),
                            style: IconButton.styleFrom(backgroundColor: const Color(0xFF2D6A4F)),
                            onPressed: () {
                              if (!saved) {
                                OfflineAudioManager.instance.downloadTrack(
                                  id: id,
                                  title: title,
                                  reciter: name,
                                  url: url,
                                );
                              }
                            },
                          ),
                        const SizedBox(width: 8),
                        IconButton(
                          icon: const Icon(Icons.play_arrow_rounded, color: Colors.black),
                          style: IconButton.styleFrom(backgroundColor: const Color(0xFFC9A959)),
                          onPressed: () => onPlayAudio(
                            id: id,
                            title: title,
                            reciter: name,
                            reciterData: reciterData,
                            url: url,
                          ),
                        ),
                      ],
                    ),
                  );
                },
              );
            },
          );
        },
      ),
    );
  }
}

// ============================================================================
// 11. TAB 5: ريلز (مطابق للصورة الخامسة والسادسة: أزرار جانبية + بروفايل القارئ + دعم Catbox.moe)
// ============================================================================
class OriginalReelsTab extends StatelessWidget {
  const OriginalReelsTab({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('videos').snapshots(),
        builder: (context, snap) {
          final docs = snap.data?.docs ?? [];
          if (docs.isEmpty) {
            return const Center(child: Text('لا توجد فيديوهات ريلز حالياً', style: TextStyle(color: Colors.white70)));
          }
          return PageView.builder(
            scrollDirection: Axis.vertical,
            itemCount: docs.length,
            itemBuilder: (context, i) {
              final v = docs[i].data() as Map<String, dynamic>;
              return OriginalReelItemWidget(videoId: docs[i].id, data: v);
            },
          );
        },
      ),
    );
  }
}

class OriginalReelItemWidget extends StatefulWidget {
  final String videoId;
  final Map<String, dynamic> data;
  const OriginalReelItemWidget({super.key, required this.videoId, required this.data});

  @override
  State<OriginalReelItemWidget> createState() => _OriginalReelItemWidgetState();
}

class _OriginalReelItemWidgetState extends State<OriginalReelItemWidget> {
  VideoPlayerController? _vc;
  bool _failed = false;
  bool _liked = false;

  @override
  void initState() {
    super.initState();
    _initVideo();
  }

  Future<void> _initVideo() async {
    final url = (widget.data['video_url'] ?? '').toString().trim();
    if (url.isEmpty) {
      setState(() => _failed = true);
      return;
    }
    try {
      _vc = VideoPlayerController.networkUrl(
        Uri.parse(url),
        httpHeaders: const {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
          'Accept': '*/*',
        },
      );
      await _vc!.initialize();
      await _vc!.setLooping(true);
      await _vc!.play();
      if (mounted) setState(() {});
    } catch (_) {
      if (mounted) setState(() => _failed = true);
    }
  }

  @override
  void dispose() {
    _vc?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final reciterName = (widget.data['reciter_name'] ?? 'منصور السالمي').toString();
    final title = (widget.data['title'] ?? '').toString();
    final url = (widget.data['video_url'] ?? '').toString().trim();

    return Stack(
      fit: StackFit.expand,
      children: [
        if (_failed)
          Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.videocam_off_rounded, color: Color(0xFFC9A959), size: 48),
                const SizedBox(height: 10),
                const Text('تعذر تشغيل الرابط مباشرة'),
                const SizedBox(height: 10),
                ElevatedButton(
                  onPressed: () => launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication),
                  child: const Text('فتح الفيديو'),
                ),
              ],
            ),
          )
        else if (_vc != null && _vc!.value.isInitialized)
          GestureDetector(
            onTap: () => _vc!.value.isPlaying ? _vc!.pause() : _vc!.play(),
            child: FittedBox(
              fit: BoxFit.cover,
              child: SizedBox(
                width: _vc!.value.size.width,
                height: _vc!.value.size.height,
                child: VideoPlayer(_vc!),
              ),
            ),
          )
        else
          const Center(child: CircularProgressIndicator(color: Color(0xFFC9A959))),

        // Left Action Column (نفس الصورة الخامسة: صورة القارئ الدائرية الذهبية + أعجبني + مشاركة + تحميل)
        Positioned(
          left: 14,
          bottom: 35,
          child: Column(
            children: [
              GestureDetector(
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => OriginalReciterProfileScreen(reciterName: reciterName, reciterData: widget.data),
                  ),
                ),
                child: Column(
                  children: [
                    ReciterAvatarImage(data: widget.data, size: 52, borderWidth: 2.5),
                    const SizedBox(height: 4),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                      decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(10)),
                      child: Text(
                        reciterName,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 9, color: Color(0xFFC9A959)),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              _actionCircle(
                icon: Icons.favorite_rounded,
                label: 'أعجبني',
                bg: _liked ? const Color(0xFFFF4757) : const Color(0xFF0F2B3D).withOpacity(0.75),
                onTap: () => setState(() => _liked = !_liked),
              ),
              const SizedBox(height: 14),
              _actionCircle(
                icon: Icons.share_rounded,
                label: 'مشاركة',
                bg: const Color(0xFF0F2B3D).withOpacity(0.75),
                onTap: () => launchUrl(Uri.parse('https://api.whatsapp.com/send?text=${Uri.encodeComponent('$title\n$url')}'),
                    mode: LaunchMode.externalApplication),
              ),
              const SizedBox(height: 14),
              _actionCircle(
                icon: Icons.download_rounded,
                label: 'تحميل',
                bg: const Color(0xFF2D6A4F),
                onTap: () => launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication),
              ),
            ],
          ),
        ),

        // Bottom Right Title & Reciter Name (نفس الصورة الخامسة)
        Positioned(
          right: 16,
          bottom: 35,
          left: 90,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Icon(Icons.videocam_rounded, color: Color(0xFFC9A959), size: 18),
                  const SizedBox(width: 6),
                  Expanded(
                    child: Text(
                      title.isNotEmpty ? title : reciterName,
                      style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: Color(0xFFC9A959)),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 4),
              Text(reciterName, style: const TextStyle(fontSize: 13, color: Colors.white70)),
            ],
          ),
        ),
      ],
    );
  }

  Widget _actionCircle({required IconData icon, required String label, required Color bg, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: bg,
              shape: BoxShape.circle,
              border: Border.all(color: const Color(0xFFC9A959).withOpacity(0.35), width: 1.5),
            ),
            child: Icon(icon, color: Colors.white, size: 20),
          ),
          const SizedBox(height: 4),
          Text(label, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w600, color: Colors.white)),
        ],
      ),
    );
  }
}

// ============================================================================
// 12. RECITER PROFILE SCREEN (مطابق للصورة السادسة: صورة القارئ + @username + فيديو / إعجاب + شبكة 3 أعمدة)
// ============================================================================
class OriginalReciterProfileScreen extends StatelessWidget {
  final String reciterName;
  final Map<String, dynamic> reciterData;

  const OriginalReciterProfileScreen({
    super.key,
    required this.reciterName,
    required this.reciterData,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(backgroundColor: Colors.black, elevation: 0),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('videos').where('reciter_name', isEqualTo: reciterName).snapshots(),
        builder: (context, snap) {
          final vids = snap.data?.docs ?? [];
          return Column(
            children: [
              ReciterAvatarImage(data: reciterData, size: 96, borderWidth: 2),
              const SizedBox(height: 12),
              Text('@$reciterName', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white)),
              const SizedBox(height: 14),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Column(
                    children: [
                      Text('${vids.length}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
                      const Text('فيديو', style: TextStyle(fontSize: 12, color: Colors.white60)),
                    ],
                  ),
                  const SizedBox(width: 36),
                  const Column(
                    children: [
                      Text('23', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
                      Text('إعجاب', style: TextStyle(fontSize: 12, color: Colors.white60)),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 18),
              const Divider(color: Colors.white12, height: 1),
              Expanded(
                child: GridView.builder(
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                    mainAxisSpacing: 2,
                    crossAxisSpacing: 2,
                    childAspectRatio: 9 / 16,
                  ),
                  itemCount: vids.length,
                  itemBuilder: (context, i) {
                    final v = vids[i].data() as Map<String, dynamic>;
                    return Container(
                      color: const Color(0xFF0A0F1E),
                      child: Stack(
                        fit: StackFit.expand,
                        children: [
                          if ((v['thumbnail'] ?? '').toString().isNotEmpty)
                            Image.network(v['thumbnail'], fit: BoxFit.cover)
                          else
                            const Icon(Icons.play_circle_outline_rounded, color: Color(0xFFC9A959), size: 36),
                          const Positioned(
                            top: 8,
                            left: 8,
                            child: Icon(Icons.play_arrow_rounded, color: Colors.white, size: 18),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

// ============================================================================
// 13. AZKAR, HADITH, TASBIH, CALENDAR & DOWNLOADS SCREENS
// ============================================================================
class OriginalAzkarScreen extends StatelessWidget {
  const OriginalAzkarScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A1A15),
      appBar: AppBar(backgroundColor: const Color(0xFF0A2A25), title: const Text('الأذكار', style: TextStyle(color: Color(0xFF10B981)))),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('azkar').snapshots(),
        builder: (context, snap) {
          final docs = snap.data?.docs ?? [];
          if (docs.isEmpty) {
            return const Center(child: Text('أصبحنا وأصبح الملك لله والحمد لله'));
          }
          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: docs.length,
            separatorBuilder: (_, __) => const Divider(color: Colors.white12),
            itemBuilder: (context, i) {
              final z = docs[i].data() as Map<String, dynamic>;
              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 10),
                child: Text(z['text'] ?? '', style: const TextStyle(fontSize: 18, height: 1.9)),
              );
            },
          );
        },
      ),
    );
  }
}

class OriginalHadithScreen extends StatelessWidget {
  const OriginalHadithScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A1A15),
      appBar: AppBar(backgroundColor: const Color(0xFF0A2A25), title: const Text('الأحاديث النبوية', style: TextStyle(color: Color(0xFF10B981)))),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('hadiths').snapshots(),
        builder: (context, snap) {
          final docs = snap.data?.docs ?? [];
          if (docs.isEmpty) {
            return const Center(child: Text('قال رسول الله ﷺ: خيركم من تعلم القرآن وعلمه'));
          }
          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: docs.length,
            separatorBuilder: (_, __) => const Divider(color: Colors.white12),
            itemBuilder: (context, i) {
              final h = docs[i].data() as Map<String, dynamic>;
              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 10),
                child: Text(h['text'] ?? '', style: const TextStyle(fontSize: 18, height: 1.9)),
              );
            },
          );
        },
      ),
    );
  }
}

class OriginalTasbihScreen extends StatefulWidget {
  const OriginalTasbihScreen({super.key});

  @override
  State<OriginalTasbihScreen> createState() => _OriginalTasbihScreenState();
}

class _OriginalTasbihScreenState extends State<OriginalTasbihScreen> {
  int _count = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(backgroundColor: const Color(0xFF0D2B35), title: const Text('المسبحة الإلكترونية', style: TextStyle(color: Color(0xFFC9A959)))),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 240,
              height: 240,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: const Color(0xFFC9A959).withOpacity(0.35), width: 2),
              ),
              child: Text('$_count', style: const TextStyle(fontSize: 82, fontWeight: FontWeight.w900, color: Color(0xFFC9A959))),
            ),
            const SizedBox(height: 30),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFC9A959),
                foregroundColor: Colors.black,
                padding: const EdgeInsets.symmetric(horizontal: 64, vertical: 18),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(40)),
              ),
              onPressed: () {
                HapticFeedback.lightImpact();
                setState(() => _count++);
              },
              child: const Text('اضغط', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
            ),
            const SizedBox(height: 16),
            TextButton(onPressed: () => setState(() => _count = 0), child: const Text('إعادة تعيين')),
          ],
        ),
      ),
    );
  }
}

class OriginalCalendarScreen extends StatelessWidget {
  const OriginalCalendarScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final h = HijriCalendar.now();
    return Scaffold(
      backgroundColor: const Color(0xFF0A1A15),
      appBar: AppBar(backgroundColor: const Color(0xFF0A2A25), title: const Text('التقويم', style: TextStyle(color: Color(0xFF10B981)))),
      body: Center(
        child: Container(
          margin: const EdgeInsets.all(20),
          padding: const EdgeInsets.all(26),
          decoration: BoxDecoration(
            color: const Color(0xFF0A2A25),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: const Color(0xFF10B981).withOpacity(0.35)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('${h.hDay} ${h.longMonthName} ${h.hYear} هـ',
                  style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: Colors.white)),
              const SizedBox(height: 10),
              Text('${now.day} / ${now.month} / ${now.year} م', style: const TextStyle(fontSize: 16, color: Color(0xFFA0B9C4))),
            ],
          ),
        ),
      ),
    );
  }
}

class OriginalDownloadsScreen extends StatelessWidget {
  final Function({required String id, required String title, required String reciter, required Map<String, dynamic> reciterData, required String url}) onPlayAudio;
  const OriginalDownloadsScreen({super.key, required this.onPlayAudio});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(backgroundColor: const Color(0xFF0D2B35), title: const Text('التنزيلات أوفلاين', style: TextStyle(color: Color(0xFFC9A959)))),
      body: AnimatedBuilder(
        animation: OfflineAudioManager.instance,
        builder: (context, _) {
          final items = OfflineAudioManager.instance.tracks;
          if (items.isEmpty) return const Center(child: Text('لا توجد سور محمّلة بعد'));
          return ListView.separated(
            padding: const EdgeInsets.all(14),
            itemCount: items.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (context, i) {
              final t = items[i];
              return ListTile(
                tileColor: const Color(0xFF1A4755),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                title: Text(t['title'] ?? ''),
                subtitle: Text(t['reciter'] ?? ''),
                trailing: IconButton(
                  icon: const Icon(Icons.play_arrow_rounded, color: Color(0xFFC9A959)),
                  onPressed: () => onPlayAudio(
                    id: t['id'],
                    title: t['title'] ?? '',
                    reciter: t['reciter'] ?? '',
                    reciterData: {'name': t['reciter'] ?? ''},
                    url: t['localPath'] ?? '',
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
